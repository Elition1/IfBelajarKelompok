/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.event.ActionEvent;
import javafx.scene.layout.AnchorPane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import kendaraanPackage.*;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.fxml.Initializable;

public class AdminControl implements Initializable {
    @FXML private AnchorPane PanelDaftar, PanelTambah, PanelRemove, PanelRiwayat;
    
    @FXML private TableView<Kendaraan> tabRemove;
    @FXML private TableColumn<Kendaraan, String> colTipe2, colMerek2, colNama2, colSeri2;
    @FXML private TableColumn<Kendaraan, Double>colHarga2;
    
    @FXML private ComboBox<String> cmbJenis, cmbMerek, cmbStatus;
    @FXML private TextField txtHarga, txtDeskripsi;
    
    @FXML private TableView<Kendaraan> tabelDaftar;
    @FXML private TableColumn<Kendaraan, String> colTipe, colMerek, colNama, colSeri;
    @FXML private TableColumn<Kendaraan, Double> colHarga;
    @FXML private ComboBox<String> cmbMerekFilter, cmbHarga, cmbDaftarKendaraan;
    
    private SistemRental sisRental = SistemRental.getInstance();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cmbJenis.setItems(FXCollections.observableArrayList("Mobil", "Motor"));
        cmbMerek.setItems(FXCollections.observableArrayList("Toyota", "Honda", "Yamaha", "Suzuki", "BMW"));
        cmbStatus.setItems(FXCollections.observableArrayList("Tersedia", "Sedang Dirental"));
        setupTabelHapus();
        setupTabelDaftar();
        muatDataTabel();
    }
    private void setupTabelHapus() {
        colTipe2.setCellValueFactory(new PropertyValueFactory<>("tipeKendaraan"));
        colMerek2.setCellValueFactory(new PropertyValueFactory<>("merek"));
        colNama2.setCellValueFactory(new PropertyValueFactory<>("nama"));
        colSeri2.setCellValueFactory(new PropertyValueFactory<>("seri"));
        colHarga2.setCellValueFactory(new PropertyValueFactory<>("hargaSewa"));
    }
    
    private void setupTabelDaftar() {
        colTipe.setCellValueFactory(new PropertyValueFactory<>("tipeKendaraan"));
        colMerek.setCellValueFactory(new PropertyValueFactory<>("merek"));
        colNama.setCellValueFactory(new PropertyValueFactory<>("nama"));
        colSeri.setCellValueFactory(new PropertyValueFactory<>("seri"));
        colHarga.setCellValueFactory(new PropertyValueFactory<>("hargaSewa"));
    
    }
    
    private void muatDataTabel() {
        Kendaraan[] semua = sisRental.semuaKendaraan();
        ObservableList<Kendaraan> data = FXCollections.observableArrayList();
        for (Kendaraan k : semua) {
            if (k != null) data.add(k);
        }
        tabelDaftar.setItems((data));
        if(tabRemove != null) tabRemove.setItems(data);
    }
    @FXML
    public void btnSimpanKendaraan() {
        String jenis = cmbJenis.getValue();
        String merek = cmbMerek.getValue();
        String hargaStr = txtHarga.getText().trim();
        String deskripsi = txtDeskripsi.getText().trim();
        
        if (jenis ==null || merek == null || hargaStr.isEmpty() || deskripsi.isEmpty()) {
            Peringatan("Error", "Ada data yang masih kosong!");
        return;
        }
        try {
            double harga = Double.parseDouble(hargaStr);
            String hasil;
            
            if (jenis.equals("Mobil")) {
                String seri = "MOB-" + (sisRental.getJmlMobil() + 1);
                Mobil baru = new Mobil(merek, merek, seri, harga, deskripsi, 4);
                hasil = sisRental.tambahMobil(baru);
        } else {
                String seri = "MOT-" + (sisRental.getJmlMotor() + 1);
                Motor baru = new Motor(merek, merek, seri, harga, deskripsi, "Matic");
                hasil = sisRental.tambahMotor(baru);
            }
            if (!hasil.equals("Selesai")) {
                Peringatan("Stok Penuh!", hasil);
                return;
            }
            muatDataTabel();
            Peringatan("Berhasil", "Kendaraan berhasil ditambahkan!\n"
                    + "Sisa slot Mobil : " + (sisRental.MAX_MOBIL - sisRental.getJmlMobil())
                    + "\nSisa slot Motor : " + (sisRental.MAX_MOTOR - sisRental.getJmlMotor()));
            cmbJenis.setValue(null);
            cmbMerek.setValue(null);
            cmbStatus.setValue(null);
            txtHarga.clear();
            txtDeskripsi.clear();
    } catch (NumberFormatException e) {
        Peringatan("Error", "Harga harus dengan format angka!");
    }
}
    
@FXML
public void btnRemove() {
    Kendaraan pilih = tabRemove.getSelectionModel().getSelectedItem();
    
    if(pilih == null) {
        Peringatan("Error", "Pilih Kendaraan yang akan dihapus terlebih dahulu!");
        return;
    }
    boolean berhasil;
    if (pilih instanceof Mobil) {
    berhasil = sisRental.hapusMobil(pilih.getSeri());
    } else {
        berhasil = sisRental.hapusMotor(pilih.getSeri());
    }
    if (berhasil) {
        muatDataTabel();
        Peringatan("Berhasil", "Kendaraan " + pilih.getSeri() + " berhasil dihapus!");
    } else {
        Peringatan("Error", "Gagal menghapus kendaraan!");
    }
}
    
// Sembunyikan semua, tampilkan yang dipilih
    private void tampilPane(AnchorPane aktif) {
    PanelDaftar.setVisible(false);
    PanelTambah.setVisible(false);
    PanelRemove.setVisible(false);
    PanelRiwayat.setVisible(false);
    aktif.setVisible(true);
}

    @FXML void btnLookVehicle() { tampilPane(PanelDaftar); }
    @FXML void btnAddVehicle() { tampilPane(PanelTambah); }
    @FXML void btnRemoveVehicle() { tampilPane(PanelRemove); }
    @FXML void btnRiwayatTransaksi() { tampilPane(PanelRiwayat); }
    
    @FXML
    void btnLogout(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/viewForm/login.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
     public void Peringatan (String judul, String pesan) {
        Alert peringatan = new Alert(Alert.AlertType.INFORMATION);
        peringatan.setTitle(judul);
        peringatan.setHeaderText(null);
        peringatan.setContentText(pesan);
        peringatan.showAndWait();
    }
}
